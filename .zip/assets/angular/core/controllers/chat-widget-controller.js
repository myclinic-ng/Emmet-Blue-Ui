angular.module("EmmetBlue")

.controller('chatWidgetController', function($scope, CONSTANTS, utils, $cookies){
});