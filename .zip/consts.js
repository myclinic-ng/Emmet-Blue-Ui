function getConstants(){
	var server = "https://d208-197-210-55-228.ngrok.io/"; //"http://localhost:705/";
	// var server = "https://api.emmetblue.ng/"; //"http://localhost:705/";
	// var server = "http://localhost:705/";
	var file_server = "https://emmetblue.org.ng:702/";
	var ws_server = "wss://emmetblue.org.ng/echobot";
	var client = {
		short_name: "Emmetblue",
		name: "Emmetblue",
		_style:{
			accounts:{
				billing:{
					receipt_template:{
						"logo_width":"100%"
					}
				}
			},
			user:{
				login:{
					"logo_width":"100%"
				}
			}
		}
	};

	return {
		"TEMPLATE_DIR":"plugins/",
		"MODULE_MENU_LOCATION":"assets/includes/menu.html",
		"MODULE_HEADER_LOCATION":"assets/includes/header.html",
		"EMMETBLUE_SERVER":server,
		"EMMETBLUE_SERVER_VERSION":"v1",
		"USER_COOKIE_IDENTIFIER":"_______",
		"USER_CLIENT":client,
		"WEB_SOCKET_SERVER":ws_server,
		"EMMETBLUE_FILE_SERVER":file_server
	};
}