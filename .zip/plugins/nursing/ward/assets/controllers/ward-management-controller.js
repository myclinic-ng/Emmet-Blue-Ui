angular.module("EmmetBlue")

.controller("nursingWardManagementController", function($scope, utils){
	
})