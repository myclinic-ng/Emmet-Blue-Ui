var controllersLocation = "plugins/nursing/station/assets/controllers/";

head.load(controllersLocation+'dashboard-controller.js');
head.load(controllersLocation+'payment-request-controller.js');
head.load(controllersLocation+'pharmacy-requests-controller.js');
head.load(controllersLocation+'nursing-queued-patients-controller.js');