var controllersLocation = "plugins/lab/assets/controllers/";

head.load(controllersLocation+"dashbard-controller.js");
head.load(controllersLocation+"labs-controller.js");
head.load(controllersLocation+"investigation-types-controller.js");
head.load(controllersLocation+"lab-requests-controller.js");
head.load(controllersLocation+"lab-results-controller.js");
head.load(controllersLocation+"investigation-type-fields-controller.js");
head.load(controllersLocation+"patient-controller.js");
head.load(controllersLocation+"patient-database-controller.js");
head.load(controllersLocation+"new-patient-controller.js");
head.load(controllersLocation+"payment-request-controller.js");
head.load(controllersLocation+"verify-hmo-proceed-controller.js");
head.load(controllersLocation+"published-results-controller.js");

head.load(controllersLocation+"old-lab-results-controller.js");
head.load(controllersLocation+"lab-results/lab-result-form-directive.js");