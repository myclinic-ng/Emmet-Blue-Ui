angular.module("EmmetBlue")

.controller("labDashboardController", function($scope, utils){
	window.location.href="/lab/lab-requests";
})