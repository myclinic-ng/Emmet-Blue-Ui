angular.module("EmmetBlue")

.controller("accountsBillingDashboardController", function($scope, utils){
	$scope.dashboardMessage = "Accounts Billing Dashboard";
})