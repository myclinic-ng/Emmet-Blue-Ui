var controllersLocation = "plugins/accounts/hmo/assets/controllers/";

head.load(controllersLocation+"dashboard-controller.js");
head.load(controllersLocation+"hmo-patients-database-controller.js");
head.load(controllersLocation+"hmo-unprocessed-requests-controller.js");
head.load(controllersLocation+"hmo-current-in-patients-controller.js");
head.load(controllersLocation+"new-hmo-profile-controller.js");
head.load(controllersLocation+"hmo-documents-controller.js");
head.load(controllersLocation+"transactions-controller.js");