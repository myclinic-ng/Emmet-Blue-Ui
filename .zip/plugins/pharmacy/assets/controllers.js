var controllersLocation = "plugins/pharmacy/assets/controllers/";

head.load(controllersLocation+"manage-stores-controller.js");
head.load(controllersLocation+"store-inventory-controller.js");
head.load(controllersLocation+"dispensation-controller.js");
head.load(controllersLocation+"reports-controller.js");
head.load(controllersLocation+"transfer-reports-controller.js");
head.load(controllersLocation+"restock-reports-controller.js");
head.load(controllersLocation+"purchase-invoice-controller.js");
head.load(controllersLocation+"dashboard-controller.js");
head.load(controllersLocation+"new-store-restock-controller.js");
head.load(controllersLocation+"store-transfer-controller.js");
head.load(controllersLocation+"inventory-controller.js");
head.load(controllersLocation+"dashboard-store-inventory-controller.js");
head.load(controllersLocation+"store-management-segment-controller.js");
head.load(controllersLocation+"statistics-dashboard-controller.js");
head.load(controllersLocation+"stock-value-dashboard-controller.js");
head.load(controllersLocation+"sales-pulse-dashboard-controller.js");

head.load(controllersLocation+"setting/dispensory-store-link-controller.js");
head.load(controllersLocation+"setting/dispensories-controller.js");