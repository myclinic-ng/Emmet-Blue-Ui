var controllersLocation = "plugins/mortuary/assets/controllers/";

head.load(controllersLocation+'body-controllers.js');
head.load(controllersLocation+'manage-bodies-controller.js');
head.load(controllersLocation+'dashboard-controller.js');
head.load(controllersLocation+'logging-out-body-controller.js');
head.load(controllersLocation+'logging-in-body-controller.js');