angular.module("EmmetBlue")

.controller('mortuaryDashboardController', function($scope, $http, CONSTANTS){
});