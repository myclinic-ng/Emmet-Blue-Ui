var controllersLocation = "plugins/human-resources/assets/controllers/";

head.load(controllersLocation+'dashboard-controller.js');
head.load(controllersLocation+'department-group-controller.js');
head.load(controllersLocation+'department-root-controller.js');
head.load(controllersLocation+'department-controller.js');
head.load(controllersLocation+'department-role-controller.js');
head.load(controllersLocation+'department-staff-management-controller.js');
head.load(controllersLocation+'settings/staff-profile-records-controller.js');
head.load(controllersLocation+'department-new-staff-profile-controller.js');
head.load(controllersLocation+'access-control-controller.js');