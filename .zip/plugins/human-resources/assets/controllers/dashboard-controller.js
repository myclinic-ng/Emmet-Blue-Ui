angular.module("EmmetBlue")

.controller('humanResourcesDashboardController', function($scope, $http, CONSTANTS){
	$scope.dashboardMessage="Welcome to the Human Resources Dashboard";
});