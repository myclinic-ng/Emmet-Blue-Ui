var controllersLocation = "plugins/human-resources/it/assets/controllers/";

head.load(controllersLocation+'control-panel-controller.js');