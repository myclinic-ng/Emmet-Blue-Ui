var controllersLocation = "plugins/financial-audit/assets/controllers/";

head.load(controllersLocation+"patient-flow-controller.js");